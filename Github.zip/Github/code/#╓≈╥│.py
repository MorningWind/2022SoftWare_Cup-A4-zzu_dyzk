import streamlit as st

#主页UI布局
st.markdown("# 主页 🎈")
st.sidebar.markdown("# 主页 🎈 ")
st.sidebar.markdown("本系统由来自郑州大学的zzu_dyzk+27011647团队制作")
st.sidebar.markdown("队长:杨晓阳 队员:钱昊晨")
st.title("遥感图像自动解译系统——zzu_dyzk")
st.image("picture.jpg")
st.subheader("欢迎使用！请于左侧栏选用功能！")
























